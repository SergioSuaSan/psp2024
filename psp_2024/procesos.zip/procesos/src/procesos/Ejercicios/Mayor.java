package procesos.Ejercicios;

public class Mayor {

	private static int elMayor(int x, int y) { //método al que le pasamos dos numeros 
		if(x>y) return x; //hacemos una comparación para ver el mayor y retornamos el mayor 
		else return y;
	}
	
	public static void main(String[] args) {
    
	if (args.length == 2) {	//Se verifica si se han pasado exactamente dos argumentos (args.length == 2)
	int x = Integer.valueOf(args[0]); //Los argumentos se convierten de String a int utilizando Integer.valueOf()
    int y = Integer.valueOf(args[1]);
    int resultado = elMayor(x,y); //guardamos en el resultado el mayor
    System.out.println(resultado); //imprimimos el resultado 
	}
	}



}
