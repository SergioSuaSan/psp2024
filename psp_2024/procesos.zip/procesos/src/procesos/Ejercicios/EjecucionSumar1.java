package procesos.Ejercicios;
import java.io.IOException;

public class EjecucionSumar1 {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		
		CrearProcesoSumar cps = new CrearProcesoSumar(15, 55, "primero.txt");  //creamos objetos sumar y le pasamos parametrso 
		CrearProcesoSumar cps2 = new CrearProcesoSumar(555, 999, "segundo.txt");
		
		cps.getP().waitFor(); //tienen que acabar los procesos hijos, es decir que a cp le den un proceso, para que pueda ejecutarse el proceso padre  (que es getResultadoSuma)
		cps2.getP().waitFor();
		
		
		int primerResultado = cps.getResultadoSuma();
		int segundoResultado = cps2.getResultadoSuma();
		
		System.out.println(primerResultado+segundoResultado);
		
		
		

	}

}
