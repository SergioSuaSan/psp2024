package procesos.Ejercicios;

public class PrimosEntreSi_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = Integer.valueOf(args[0]);
		int y = Integer.valueOf(args[1]);
		/*
		 * Se obtienen dos argumentos de la línea de comandos y se convierten de String a int utilizando Integer.valueOf().
		y se asignan a las variables x y y
		 */
		if (sonPrimosEntreSi(x, y)) {
			System.out.println("Los números son primos entre sí");
		}
		else {
			System.out.println("Los números no son primos entre sí");
		}
	
	}

	static boolean sonPrimosEntreSi(int x, int y) { //creamos un metodo que nos devuelva un boolean si son primos o no pasando dos numeros 
		boolean res = false; //empezamos en faslso el res 
		if(x % y != 0 && y % x != 0 ) {	//comprueba si x no es divisible por y y viceversa.
			res = true;
		}
		return res;
	}
}
