package procesos.Ejercicios;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CrearProcesoMayor {
	//atributos de la clase  
	private int num1;
	private int num2;
	private String fich;
	Process p;
	
	//método que crea el proceso mayor 
	public CrearProcesoMayor(int i, int j, String fich1) {	//parametros sque le pasamos 
		this.num1 = i;
		this.num2 = j;
		this.fich = fich1;
		String x = String.valueOf(i); //parseamos esos numeros llamando x al i 
		String y = String.valueOf(j); //parseamos esos numeros llamando y al j 
		//Si escribimos el comando java sin classpath (o una inadecuada), hay que usar directory
		//ProcessBuilder pb = new ProcessBuilder("java", "procesos.Ejercicios.Mayor", x, y);
		//Si escribimos el comando java con classpath del modo que se ve a continuación
		//no es necesario usar directory
		ProcessBuilder pb = new ProcessBuilder("java", "-cp" , ".\\bin", "procesos.Ejercicios.Mayor", x, y); 
		//creamos un processbuilder con todos los comandos necesarios pasandoselos como string. 
		//System.out.println(x);
		//pb.directory(new File("C:\\Users\\Eugenio\\eclipse-workspace_java\\psp_2024\\bin"));
		pb.redirectOutput(new File(this.fich)); //a todo lo que el proceso escriba en la salida estandar  se guardará en este archivo 
		
		pb.redirectError(new File("C:\\Users\\Usuario\\OneDrive\\Escritorio\\2º DAM\\WorkSpace PSP\\procesos\\src\\procesos\\Ejercicios\\mayor\\error1.txt\""));
		
		//los mensajes de error generados por el proceso se guardarán en ese archivo 
		try {
			this.p = pb.start(); //ejecuta el proceso 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Process getP() { //método retorna un proceso 
		return p;
	}

	public void setP(Process p) { //método que establece el proceso 
		this.p = p;
	}

	public int getResultadoMayor() //método que devuelve el resultado mayor 
	{
		int resultado = 0; //establecemos que el resultado es 0 
		try {
			FileReader  fr = new FileReader(this.fich); // Se crea un FileReader para leer el archivo especificado en this.fich
			BufferedReader br = new BufferedReader(fr); // Se envuelve el FileReader en un BufferedReader para leer líneas de texto de forma eficiente
			String result = br.readLine();      // Se lee la primera línea del archivo
			resultado = Integer.valueOf(result); // Se convierte la cadena leída a un entero y se asigna a 'resultado'
			br.close(); // Se cierra el BufferedReader para liberar los recursos
			return resultado; //Devolvemos el resultado 
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return resultado;  // Si ocurre un error, se devuelve el valor inicial de resultado (0)
	}
	
}
