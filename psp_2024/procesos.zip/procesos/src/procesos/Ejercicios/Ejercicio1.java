package procesos.Ejercicios;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		CrearProcesoMayor p1 = new CrearProcesoMayor(4,113,"C:\\Users\\Usuario\\OneDrive\\Escritorio\\2º DAM\\WorkSpace PSP\\procesos\\src\\procesos\\Ejercicios\\mayor\\fich1.txt\\");
		CrearProcesoMayor p2 = new CrearProcesoMayor(15,6,"C:\\Users\\Usuario\\OneDrive\\Escritorio\\2º DAM\\WorkSpace PSP\\procesos\\src\\procesos\\Ejercicios\\mayor\\fich2.txt");
		//Creamos dos instancias de CrearProcesoMayor a la que le pasamos como parámetros dos numeros y una ruta de ditectorios 
		
		try {
			p1.getP().waitFor(); //Aquí se espera a que los procesos asociados a p1 y p2 terminen de ejecutarse, que lo que hacen realmente es obtener un proceso 
			p2.getP().waitFor();
			int x = p1.getResultadoMayor(); //Después de que ambos procesos han terminado, se obtienen los resultados de cada proceso mediante getResultadoMayor()
			int y = p2.getResultadoMayor();
			CrearProcesoMayor p3 = new CrearProcesoMayor(x,y,"C:\\Users\\Usuario\\OneDrive\\Escritorio\\2º DAM\\WorkSpace PSP\\procesos\\src\\procesos\\Ejercicios\\mayor\\fich3.txt");
			//Se crea un tercer objeto p3, pasando como parámetros los resultados x e y, junto con una ruta de archivo para almacenar el resultado final.
			p3.getP().waitFor(); //esperamos a que el proceso termine 
			int z = p3.getResultadoMayor(); //se obtiene el resultado mayor del tercer proceso p3 y se imprime en la consola.
			System.out.println(z);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
