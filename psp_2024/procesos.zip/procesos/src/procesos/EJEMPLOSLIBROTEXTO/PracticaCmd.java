package procesos.EJEMPLOSLIBROTEXTO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Esta clase muestra le ejecución de una clase -p. e. dir- del CMD de Windows, 
 * su lectura por parte del proceso padre y su salida por pantalla. 
 * Esta versión incluirá todo dentro de un solo método main. 
 */
public class PracticaCmd {
	public static void main(String[] args) throws IOException {
		/*
		//crear el proceso de inicio del comando
		ProcessBuilder pb = new ProcessBuilder("CMD", "/C", "DIR"); //dentro del parentesis podemos el programa de ejecuccion 
		Process p = pb.start(); 
		
		//Lectura de la salida del proceso hijo desde el padre
		InputStream is = p.getInputStream(); 
		InputStreamReader isr = new InputStreamReader(is); //le debes pasar un InputStream 
		BufferedReader br = new BufferedReader(isr); //le debes pasar un InputStreamReader 
		String linea = null; 
		while ((linea = br.readLine()) !=null) {
			System.out.println(linea );
		}
		/* int c; 
		while ((c = is.read()) !=-1) {
			System.out.print((char) c);
		} 
		/*ArrayList<String> comanditos = {"CMD", "/C", "DIR"};  
		
		lectura(comanditos); */
		ArrayList<String> comanditos =  dameComandos(); 
		lectura(comanditos);
		
	}
	
	public static ArrayList<String> dameComandos() {
		boolean bandera = true; 
		ArrayList<String> comanditos = new ArrayList<String>(); 
		Scanner teclado = new Scanner(System.in);
		while (bandera) {
			 System.out.println("Introduce un comando o 'FIN' para terminar:"); 
			String comando = teclado.nextLine(); 
			if (!comando.equals("FIN")) {
				comanditos.add(comando); 
			} else {
				bandera = false; 
			}
		}
		teclado.close();  // Cierra el Scanner
		return comanditos; 
	}
	
	public static void lectura(ArrayList<String> comandos) throws IOException {
		//crear el proceso de inicio del comando
		ProcessBuilder pb = new ProcessBuilder(comandos); //dentro del parentesis podemos el programa de ejecuccion 
		Process p = pb.start(); 
		
		
		InputStream is = p.getInputStream(); //permite que el proceso padre lea la salida del subproceso hijo
		InputStreamReader isr = new InputStreamReader(is); //le debes pasar un InputStream  
		BufferedReader br = new BufferedReader(isr); //le debes pasar un InputStreamReader 
		String linea = null; 
		while ((linea = br.readLine()) !=null) {
			System.out.println(linea );
		}
		/* int c; 
		while ((c = is.read()) !=-1) {
			System.out.print((char) c);
		} */
		
		
	
		
		
	}
}

/*
 * •	getInputStream(): Permite leer la salida del proceso hijo. Es decir permite leer que el proceso padre lea del subproceso hijo. 
•	getOutputStream(): Permite enviar datos de entrada al proceso hijo. Es decir permite que el proceso padre escriba en el subproceso hijo

 */
