package procesos.EJEMPLOSLIBROTEXTO;
import java.io.IOException;

	/*
	 * Diferentes sintaxis para el lanzamiento de un proceso sencillo:
	 * ejecución de un programa del sistema operativo.
	 */

	public class Ejemplo1 {
	   public static void main(String[] args) throws IOException, InterruptedException   {	   
		   ProcessBuilder pb = new ProcessBuilder("C:\\Program Files\\AutoFirma\\AutoFirma\\AutoFirma.exe"); //constructor de procesos
		   //ProcessBuilder pb = new ProcessBuilder("EXCEL").start();  //NO VALE
		   //Process p = new ProcessBuilder("EXCEL").start();
		   //pb.start();
		   
		   ProcessBuilder pb2 = new ProcessBuilder("notepad");
		   Process p = pb.start(); //el ProcessBuilder si le das al método star devuelve un Porcess que es el que estamos llamando p
		   
		   p.waitFor(); //espera a que termine un proceso para que el otro pueda empezar 
		   
		   System.out.println(p.exitValue()); //devuelve el valor de salida del subproceso 
		   
		   Process p2 = pb2.start(); 

	   }
	}//Ejemplo1

