package procesos.EJEMPLOSLIBROTEXTO;

import java.io.IOException;

/*
 * Diferentes sintaxis para el lanzamiento de un proceso sencillo:
 * ejecución de un programa del sistema operativo.
 */

public class Ejemplo3 {
   public static void main(String[] args) throws IOException   {	   
	   ProcessBuilder pb = new ProcessBuilder("C:\\Program Files\\Microsoft Office\\Office16\\EXCEL.EXE");
	   //ProcessBuilder pb = new ProcessBuilder("EXCEL").start();  //NO VALE
	   //Process p = new ProcessBuilder("EXCEL").start();
	   //pb.start();
	   Process p = pb.start();

   }
}//Ejemplo1
//el main ES EL PROCESO PADRE y el programa que se ejecuta luego ES EL PROCESO HIJO 
 