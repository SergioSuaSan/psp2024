package procesos.EJEMPLOSLIBROTEXTO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class PracticaCmdConEscaner {
	/*
	 * Esta clase muestra la ejecución de un comando del CMD o powershell de Windows,
	 * su lectura por parte del proceso padre, y su salida por pantalla. Se recoge el 
	 * comando desde el teclado mediante un bucle usando Scanner.
	 */

	public class PracticaCmdConScanner {

		//Método para la captura de la salida del proceso hijo en este proceso padre
		public static void salida_comando(Process p) throws IOException {
					InputStream is = p.getInputStream();
					InputStreamReader isr = new InputStreamReader(is, "UTF-8");
					BufferedReader br = new BufferedReader(isr);
					
					String cadena = null;
					
					while ((cadena=br.readLine()) != null)
					{
						System.out.println(cadena);
					}
					
		}
		
		//Método para la captura de la salida de error del proceso hijo en este proceso padre
		public static void salida_comando_error(Process p) throws IOException {
					InputStream is = p.getErrorStream();
					InputStreamReader isr = new InputStreamReader(is, "UTF-8");
					BufferedReader br = new BufferedReader(isr);
					
					String cadena = null;
					
					while ((cadena=br.readLine()) != null)
					{
						System.out.println(cadena);
					}
					
		}
		
		
		//Método que permite ejecutar una lista de Strings como un comando
		public static void ejecutarCom(List<String> comando)
		{
			ProcessBuilder pb;
			Process proceso;
			
			pb = new ProcessBuilder(comando); //tiene un array de strings como comando
			try {
				proceso = pb.start(); //empezamos el proceso 
				salida_comando(proceso); //leemos del proceso hijo
				salida_comando_error(proceso); //leemos los errores del proceso hijo
				
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
		
		
		
		
		public static void main(String[] args) throws IOException {
			// TODO Auto-generated method stub
	 
			//Lista de Strings para guardar los tokens de los comandos
			List<String> comando = new ArrayList<String>();
			
			
			/*
			System.out.println("Introduce el comando del SO a ejecutar, y añade exit para finalizar");
			//Bucle para la recogida del comando -simple o con modificadores- desde el teclado
			Scanner sc = new Scanner(System.in);
			String token = null;
			while (sc.hasNext())
			{
				token = sc.next();
				if(token.equals("exit")) {
			        break;
			    }c:
				comando.add(token);
				System.out.println(comando);
				System.out.println(sc.hasNext());

			}

			*/

			System.out.println("Introduce el comando del SO a ejecutar");
			//Bucle para la recogida del comando -simple o con modificadores- desde el teclado
			Scanner sc = new Scanner(System.in);
			String linea_com = null;

			linea_com=sc.nextLine();
			StringTokenizer st = new StringTokenizer(linea_com," ");//" " es el delimitador
			while (st.hasMoreTokens() ) {
			       String s1 = st.nextToken();
			       comando.add(s1);
			        //System.out.println(s1);
			      }
		
			
			
			//Ejecución como proceso hijo del comando introducido
			ejecutarCom(comando);
			
			
			//Creación del proceso
			/*
			ProcessBuilder pb = new ProcessBuilder("CMD", "/C", "dir", "/Q", "C:\\Users");
			Process p = pb.start();
			
			salida_comando(p);
			salida_comando_error(p);
			*/
			
		}

	}

}
