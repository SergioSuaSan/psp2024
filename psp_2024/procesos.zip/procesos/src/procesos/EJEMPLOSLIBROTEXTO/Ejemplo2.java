package procesos.EJEMPLOSLIBROTEXTO;

import java.io.IOException;

public class Ejemplo2 {
	

		private static void lanzarPrograma(String comando) {
			ProcessBuilder pb = new ProcessBuilder(comando);
			try {
				
				
				Process p = pb.start();
				// esperar a que termine el proceso para poder continuar el programa principal
				p.waitFor(); 
				

			} catch (IOException | InterruptedException e) {
				System.out.println("error al lanzar el proceso");
				// e.printStackTrace();
			}
		}

		public static void main(String[] args) {

			//Si se cambia el orden de ejecución poniendo, por ejemplo, powerpnt.exe a 
			//continuación de winword.exe no funciona la espera... ver Internet en donde
			//hay información de por qué no funciona waitFor() en ocasiones.
			lanzarPrograma("C:\\Program Files\\Microsoft Office\\Office16\\winword.exe");
			
			lanzarPrograma("mspaint.exe");
			
			lanzarPrograma("POWERPNT.exe");
			
		/*	
	*/
		}


	}

