package procesos.primos;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CrearProcesoEsPrimo {
	/*
	 *  Crear una clase CrearProcesoEsPrimo que haga sirva para instanciarlo y lanzarlo como proceso, 
	 *  y que permita leer el resultado de dicha ejecución y mostrarlo por consola.
	 */
	
	//instancio
	
	private Process p;

	public Process getP() {
		return p;
	}

	public CrearProcesoEsPrimo() {
		String clase = "procesos.primos.EsPrimo"; 
		// La clase que ejecutará el proceso 
		ProcessBuilder pb = new ProcessBuilder("java", clase); 
		pb.directory(new File(".\\bin")); 
		
		try {
			pb.redirectOutput(ProcessBuilder.Redirect.INHERIT); //IMPORTANTE REDIRECT SIEMPRE ANTES DE EMPEZAR EL PROCESO PARA QUE ME ESCRIBA DE CONSOLA
			
			pb.redirectInput(ProcessBuilder.Redirect.INHERIT); //PARA QUE ME LEA DE CONSOLA 
			p = pb.start();  
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
