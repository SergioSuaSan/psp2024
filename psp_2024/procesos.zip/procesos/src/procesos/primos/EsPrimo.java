package procesos.primos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class EsPrimo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		   InputStreamReader in = new InputStreamReader(System.in);
		   BufferedReader br = new BufferedReader (in);
		   String texto;

		    System.out.println("Introducir un número");
		    texto= br.readLine();
		    int x = Integer.valueOf(texto);
		    x = Math.abs(x);
		    

		/*Scanner teclado = new Scanner(System.in); 
		System.out.println("Introduce un número: ");
		int x = teclado.nextInt(); */
		if (esPrimo(x)) {
			System.out.println("El número es primo");
		}
		else {
			System.out.println("El número no es primo");
		}
		
	}

	static boolean esPrimo(int x) {
		boolean res = true;
		int aux = 0;
		for(int i = 2; i < x; i++) {
			if(x % i == 0) {	
				res = false;
				return res;
			}
		}

		return res;
	}

}
