package procesos.primos;

import java.io.IOException;

public class EjecutaPrimo {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		//creamos una instancia de CrearProcesoEsPrimo
		CrearProcesoEsPrimo crearProcesoEsPrimo = new CrearProcesoEsPrimo(); 
		 crearProcesoEsPrimo.getP().waitFor(); 
		/*
		 *Se llama al método getP() de la instancia cpp1, que debería retornar un objeto de tipo Process
		  se llama al método waitFor() en ese objeto Process
		Esto hace que el hilo actual (el que ejecuta este código) se bloquee hasta que el proceso asociado haya finalizado su ejecución.
		 */
		
		
	}

}
