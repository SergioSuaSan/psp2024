package procesos.Repaso;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class RepasoCmd {
	/*
	 * Crear una clase RepasoCmd con los siguientes métodos:  1) main, que instancia y lanza un proceso cualquiera mediante cmd 
	 * y que muestra por consola el resultado de la ejecución del comando ejecutado mediante getResultadoCmd si  se ha ejecutado correctamente 
	 * y mediante getErrorCmd si ha habido un error al ejecutar el "comando" elegido.
	 */
	
		
		

	public static void main(String[] args) throws InterruptedException {
		//en main tenemos que instanciar la clase
		
		RepasoCmd repaso = new RepasoCmd(); //instanciamos la clases 
		// Definir el comando que se desea ejecutar (en este caso, "ipconfig" como ejemplo)
        String comando = "ipconfig"; // Puedes cambiar esto por el comando que prefieras
        
        try {
            // Ejecutar el comando y obtener el resultado 
           String resultado =  repaso.ejecutarComando(comando);
            System.out.println("Resultado del comando:\n" + resultado);
        } catch (IOException e) {
        	// Si hay un error, mostrarlo
            String error = repaso.getErrorCmd(e);
            System.out.println("Error al ejecutar el comando:\n" + repaso.getErrorCmd(e));
        }
		
	}
	
	//método para ejecutar el comando y devolver el resultado 
	public String ejecutarComando(String comando) throws IOException, InterruptedException {
		ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", comando); //para que se ejecute en cmd 
		pb.redirectError(); //redirige la salida de error a un archivo
			Process p = pb.start();
			
			//esperamos a que el proceso termine 
			int exitCode = p.waitFor(); 
			
			  // Obtener la salida del comando (ya sea el resultado o el error)
	        if (exitCode == 0) { //si el proceso ha ido bien 
	            return getResultadoCmd(p);
	        } else {
	            return getErrorCmd(new IOException("El proceso terminó con código: " + exitCode));
	        }
	        
    }

    private String getResultadoCmd(Process p) throws IOException {
    	// Leer la salida del comando
        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
        //getInputStream permite al proceso padre que lea los resultados generados por el proceso hijo (en este caso el proceso hijo es ipconfig)
        
        StringBuilder resultado = new StringBuilder(); //StringBuilder modifica la cadena actual sin crear un nuevo objeto cada vez
        String linea;

        while ((linea = reader.readLine()) != null) {
            resultado.append(linea).append("\n");
        }

        return resultado.toString();
	}

	// Método para obtener el error del comando si ocurre una excepción
    public String getErrorCmd(IOException e) {
    	return "Error al ejecutar el comando: " + e.getMessage();
    
	}
}
