package procesos.Repaso;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		// Reprogramar la clase EjemploLectura para que use Scanner en vez de InputStreamReader.
/*
 * 			// CODIGO DE EjemploLectura 
		InputStreamReader in = new InputStreamReader(System.in); //canal de entrada system.in, otra clase java puede sustituir el system.in 
		//con la clase EscrituraEnProcesoJava que es el padre, entonces escribimos sobre el padre 
		   BufferedReader br = new BufferedReader (in);
		   String texto;
		   try {
		    System.out.println("Introduce una cadena....");
		    texto= br.readLine();
		    System.out.println("Cadena escrita: "+texto); 
		    //in.close();	 
		   }catch (Exception e) { e.printStackTrace();}	
 */
		
		  // Usar Scanner para leer la entrada del usuario
		        Scanner scanner = new Scanner(System.in);
		        String texto;

		        try {
		            System.out.println("Introduce una cadena...");
		            texto = scanner.nextLine();  // Leer la entrada del usuario
		            System.out.println("Cadena escrita: " + texto);
		        } catch (Exception e) {
		            e.printStackTrace();
		        } finally {
		            scanner.close();  // Cerrar el Scanner
		        }
	    }
		
	

}
