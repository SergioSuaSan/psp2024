package procesos.Repaso;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ping {

	public static void main(String[] args) {
	/*
	 *  Crear un archivo uno.txt que contenga la palabra "ping", y otro archivo dos.txt que contenga la palabra "8.8.8.8". 
	 *  Guardarlos en la carpeta raíz del proyecto en que se vaya a trabajar. Crear una clase que lea ambos archivos
	 *   y sirviéndose de un proceso ejecute la combinación de su contenido (ping 8.8.8.8), y muestre el resultado por la consola de Eclipse.
	 */
		
	    try {
            // Crear los archivos "uno.txt" y "dos.txt"
            crearArchivo("uno.txt", "ping");
            crearArchivo("dos.txt", "8.8.8.8");

            // Leer los contenidos de los archivos
            String comando = leerArchivo("uno.txt").trim();  // lee el contenido de uno.txt  --> TIENE PING 
            String direccion = leerArchivo("dos.txt").trim();  // lee el contenido de dos.txt --> TIENE 8.8.8.8

            // Combinar los contenidos para formar el comando (ej: "ping 8.8.8.8")
            String comandoCompleto = comando + " " + direccion;

            // Ejecutar el comando
            ejecutarComando(comandoCompleto);

        } catch (IOException | InterruptedException e) {
            System.out.println("Error: " + e.getMessage());
        }
		
	}
	 // Método para crear un archivo y escribir en él
    public static void crearArchivo(String rutaArchivo, String contenido) throws IOException {
        File archivo = new File(rutaArchivo); //creamos un nuevo archivo en la ruta que me pasen 
        if (!archivo.exists()) { //si el archivo no existe 
            try (FileWriter writer = new FileWriter(archivo)) { //creamos ese archivo 
                writer.write(contenido); //escribimos lo que nos pasen 
                System.out.println("Archivo " + rutaArchivo + " creado y escrito con éxito.");
            }
        } else {
            System.out.println("El archivo " + rutaArchivo + " ya existe.");
        }
    }
    
    // Método para leer el contenido de un archivo
    public static String leerArchivo(String rutaArchivo) throws IOException {
        StringBuilder contenido = new StringBuilder();
        /*
         * StringBuilder se ua construir de manera eficiente una cadena de texto a medida que se van leyendo líneas del archivo. 
         * En lugar de crear una nueva cadena en cada iteración del ciclo (lo cual es menos eficiente en términos de memoria y tiempo), 
         * el StringBuilder permite agregar cada línea al contenido sin crear nuevos objetos intermedios.
         */
        
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) { //sobre un FileReader creamos un Bufferedreader para leer 
            String linea;
            while ((linea = reader.readLine()) != null) { //mientras se puedan seguir leyendo lineas 
                contenido.append(linea); //al contenido le sumamos la linea 
            }
        }
        return contenido.toString();
    }
    

    // Método para ejecutar el comando y mostrar el resultado
    public static void ejecutarComando(String comando) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", comando); //para que se ejecute en cmd 
        pb.redirectError(ProcessBuilder.Redirect.INHERIT); // errores estándar del proceso se muestren en la consola
        													//INHERIT hace que hijo herede la salida del error del padre 
        File errorFile = new File("error_log.txt");
        pb.redirectError((errorFile)); // Redirige los errores estándar a un archivo */
        
        Process p = pb.start();

        // Leer la salida del comando y mostrarla en la consola
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
            }
        }

        // Esperar a que el proceso termine y verificar si se ejecutó correctamente
        int exitCode = p.waitFor();
        if (exitCode == 0) {
            System.out.println("Comando ejecutado con éxito.");
        } else {
            System.out.println("Error al ejecutar el comando. Código de salida: " + exitCode);
        }
    }


}
