package procesos.EjecucionComandosDeAFichero;

import java.io.File;

public class RedireccionArchivos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProcessBuilder pb = new ProcessBuilder("CMD"); 
		//creación de los archivos
		File fentrada = new File("C:\\Users\\Usuario\\OneDrive\\Escritorio\\2º DAM\\WorkSpace PSP\\procesos\\src\\procesos\\EjecucionComandosDeAFichero");
		//Es un archivo en el cual ya deben estar almacenados ciertos comandos que el proceso hijo (CMD) ejecutará.
		//Este archivo contiene el texto que será redirigido como entrada al proceso hijo.
		File fsalida = new File("salida.txt"); 
		// Archivo donde se almacenará la salida del proceso hijo. 
		//Lo que normalmente verías en la consola cuando se ejecuta un proceso, ahora se guarda en este archivo.
		File ferror = new File("error.txt"); 
		//Archivo donde se almacenarán los errores que el proceso hijo pueda generar
				
		pb.redirectInput(fentrada); // establece la entrada del proceso hijo
		/*es decir establece que el archivo fentrada será la entrada estándar del proceso hijo. 
		 * En vez de recibir la entrada desde el teclado, CMD leerá comandos desde este archivo.
		 */
		pb.redirectOutput(fsalida); //redirige la salida a un fichero fsalida
		//La salida estándar del proceso hijo (CMD) se redirige a fsalida. En vez de mostrar el resultado en la consola, lo guarda en este archivo.
		
		pb.redirectError(ferror); //Si el proceso hijo genera algún error, ese mensaje se guardará en ferror en lugar de aparecer en la consola.
		
		
		
/*//pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);
 *  haría que la salida del proceso hijo se heredara por el proceso padre,
 *   lo que significa que el resultado del proceso hijo aparecería en la consola del proceso padre 
 *   (es decir, en la terminal actual donde ejecutas el programa), en vez de ser redirigido a un archivo.
 */
	}

}
