package procesos.EjecucionComandosDeAFichero;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Jueves04 {
	//ProcessBuilder pb = new ProcessBuilder("CMD");
	/*	
		//File fentrada = new File("C:\\Users\\Eugenio\\eclipse-workspace_java\\psp_2024\\src\\psp_2024\\procesos\\procesosCMD\\comandos.bat"); 
		File fsalida = new File("salida.txt");
		File ferror = new File("error.txt");
		
		//pb.redirectInput(fentrada);
		//pb.redirectOutput(fsalida);
		//pb.redirectError(ferror);
		//pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);
		//pb.redirectError(ProcessBuilder.Redirect.INHERIT);
		*/
		
		//leer fichero
		//Para la lectura de los comandos desde el archivo comandos.bat
	//Abre un archivo comandos.bat desde la ruta especificada, permitiendo la lectura de los comandos.
		FileInputStream fis = new FileInputStream("C:\\Users\\Eugenio\\eclipse-workspace_java\\psp_2024\\src\\psp_2024\\procesos\\procesosCMD\\comandos.bat");
	//Convierte el flujo de bytes de fis en un flujo de caracteres utilizando codificación UTF-8.
		InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
	//Usa BufferedReader para leer línea por línea el archivo comandos.bat.	
		BufferedReader br = new BufferedReader(isr);
		
		
		//Cadena en donde se irán guardando las líneas para cada comando
		String linea_com = null;
		//Lista de Strings para guardar los tokens de los comandos
		List<String> comando = new ArrayList<String>();

		//Variable para controlar el valor de salida de la terminación del proceso
		//Variable para almacenar el valor de salida del proceso (aunque no está en uso en este código).
		int exitVal; 
		
		
		//Creación de las List<Strings> con los comandos
		while((linea_com=br.readLine()) != null) //Bucle que lee cada línea del archivo hasta que no queden más líneas.
		{
			comando.add("CMD"); //Agrega CMD como el primer comando a ejecutar en la lista comando.
			comando.add("/C"); // Agrega /C, que permite ejecutar el comando y luego cerrar la ventana de comando.
			
			//Descomposición de la línea en tokens y reconstrucción del comando
			//como lista de Strings.
			StringTokenizer st = new StringTokenizer(linea_com," ");//" " es el delimitador
			while (st.hasMoreTokens() ) {
			       String s1 = st.nextToken();
			       comando.add(s1);
			        //System.out.println(s1);
			      }
			
			//Creación del proceso
			ProcessBuilder pb = new ProcessBuilder(comando); //Crea un proceso utilizando la lista de comandos comando.
			Process p; //Declara el proceso p.
			

			
			try {
				p = pb.start(); //Intenta iniciar el proceso p con el comando construido.
				
				//Para ver por consola las salidas en vez de llevarlas a archivos
				//PracticaCmd.salida_comando(p);
				//PracticaCmd.salida_comando_error(p);
				
				//Lectura de las salidas de los comandos-procesos hijos 
				//y escritura a archivos de salida y de error
				//SALIDA NORMAL
				Auxiliar.salida_comando(p); //Llama al método estático salida_comando de la clase Auxiliar para manejar la salida del proceso.
						
				//ERROR
				Auxiliar.salida_comando_error(p); //Llama a salida_comando_error para manejar los errores del proceso.
				// Aquí controlamos el valor de salida con exitVal
		        exitVal = p.waitFor(); // Espera a que el proceso termine y obtiene el código de salida
		        System.out.println("El comando '" + linea_com + "' terminó con valor de salida: " + exitVal);

			/*	
				//Adicionalmente podemos controlar el éxito de la ejecución del comando
				//con la salido de waitFor().
				exitVal = p.waitFor();
				bwe.write(linea_com + " --> " + "Valor de Salida: " 
				+ String.valueOf(exitVal) + "\n\n");
				//System.out.println("Valor de Salida: " + exitVal);
				*/
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Error en comando o en entrada-salida");
			} 

			
			//System.out.println(comando); //para ver el comando si se quiere
			
			//antes de pasar al siguiente comando se eliminan todos 
			//los elementos de la lista de cadenas
			comando.clear();
		}
		
		//Cierres de canales/flujos; de no hacerse no funcionará correctamente el programa
		//bw.close();
		//bwe.close();
		br.close();
	}
}
