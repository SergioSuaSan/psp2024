package procesos.EjecucionComandosDeAFichero;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.io.IOException;

public class LeerComandoDesdeArchivo {

    public static void main(String[] args) {
        /*
         * Crea un programa que lea comandos desde un archivo (comandos.bat u otro) 
         * y muestre su salida por pantalla (en la consola de Eclipse).
         */
        try {
            // Creación de un FileInputStream para leer el archivo comandos.bat
            // Se recuperan los bytes del archivo para ser procesados
            FileInputStream fis = new FileInputStream(".\\src\\procesos\\EjecucionComandosDeAFichero\\comandos.bat");
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8"); // Se convierte el flujo de bytes a caracteres con InputStreamReader (usando UTF-8)
            BufferedReader br = new BufferedReader(isr); // Creación de un BufferedReader sobre el InputStreamReader para leer los caracteres del archivo de manera eficiente
            
            String lineaComando;
            while ((lineaComando = br.readLine()) != null) { // Mientras encontremos líneas con el BufferedReader
                ejecutarComando(lineaComando); // Ejecutamos esas líneas creando un método aparte al que le pasaremos los strings
            }
            br.close(); // Cerrar el BufferedReader después de usarlo
        } catch (FileNotFoundException e) {
            // Manejar la excepción si el archivo no se encuentra
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            // Manejar la excepción si la codificación no es soportada
            e.printStackTrace();
        } catch (IOException e) {
            // Manejar otras excepciones de IO
            e.printStackTrace();
        }
    }

    private static void ejecutarComando(String comando) {
        try {
            // Crear el ProcessBuilder para ejecutar el comando
            ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/C", comando);
            Process proceso = pb.start(); // Iniciar el proceso

            // Leer la salida estándar del comando
            try (BufferedReader salida = new BufferedReader(new InputStreamReader(proceso.getInputStream()))) {
            	/*
            	 * getInputStream que nos dara un InputStream que se utiliza para leer la salida estandar del proceso hijo 
            	 * pasamos esos byes a caracteres con InputStreamReader y luego usamos BufferedReader para leer de forma eficiente 
            	 */
                String lineaSalida;
                while ((lineaSalida = salida.readLine()) != null) { // Mientras haya líneas por leer
                    System.out.println(lineaSalida); // Imprimir la salida en consola
                }
            }

            // Leer la salida de error del comando
            try (BufferedReader error = new BufferedReader(new InputStreamReader(proceso.getErrorStream()))) {
                String lineaError;
                while ((lineaError = error.readLine()) != null) {
                    System.err.println(lineaError); // Imprimir los errores en consola
                }
            }

            // Esperar a que el proceso termine y obtener el código de salida
            int exitVal = proceso.waitFor();
            System.out.println("El comando '" + comando + "' terminó con el código de salida: " + exitVal);
        } catch (IOException | InterruptedException e) {
            System.err.println("Error al ejecutar el comando '" + comando + "': " + e.getMessage());
        }
    }
}

