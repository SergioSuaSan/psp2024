package procesos.EjecucionComandosDeAFichero;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class EjemploLectura {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InputStreamReader in = new InputStreamReader(System.in); //canal de entrada system.in, otra clase java puede sustituir el system.in 
		//// System.in es un InputStream que captura la entrada estándar (el teclado)
	
		//leyendo desde la entrada estándar (teclado) del proceso padre.
		   BufferedReader br = new BufferedReader (in); //// BufferedReader permite leer la entrada de manera eficiente
		   String texto;
		   try {
		    System.out.println("Introduce una cadena....");
		    texto= br.readLine();
		    System.out.println("Cadena escrita: "+texto); 
		    //in.close();	 
		   }catch (Exception e) { e.printStackTrace();}	
		 
	}

}
