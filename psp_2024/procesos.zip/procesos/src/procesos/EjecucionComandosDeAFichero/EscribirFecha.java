package procesos.EjecucionComandosDeAFichero;

import java.io.IOException;
import java.io.OutputStream;

public class EscribirFecha {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		//creación de proceso 
		Process p = new ProcessBuilder("cmd", "/C" ,"date").start(); 
		//a ese proceso le podemos pedir  un outputstream ya que el proceso hijo requiere la entrada de la fecha 
		OutputStream os = p.getOutputStream(); 
		os.write("02-10-24".getBytes()); 
		
		os.flush();  //El propósito de este método es forzar que los datos que están almacenados en el búfer se escriban inmediatamente al destino
		Auxiliar.salida_comando(p);
		Auxiliar.salida_comando_error(p);
	

	}
}
