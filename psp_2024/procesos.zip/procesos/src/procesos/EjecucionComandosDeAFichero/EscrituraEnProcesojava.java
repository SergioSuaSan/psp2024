package procesos.EjecucionComandosDeAFichero;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class EscrituraEnProcesojava {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		File directorio = new File(".\\bin"); 
		ProcessBuilder pb = new ProcessBuilder("java", "procesos.EjecucionComandosDeAFichero.EjemploLectura"); 
		//java porque es el comando que se va a ejecutar, y la clase que se va a ejecutar su ruta 
		pb.directory(directorio); //para indicar el directorio 
		//se ejecuta el proceso
		Process p = pb.start(); 
		
		/*
		OutputStream os = p.getOutputStream();
		os.write("Hola Manuel\n".getBytes());
		os.flush(); // vac�a el buffer de salida  */
		// escritura -- envía entrada (sintaxis alternativa)
		OutputStream os2 = p.getOutputStream(); //para que el proceso padre pueda escribir en el subproceso hijo
		OutputStreamWriter osw = new OutputStreamWriter(os2);
		osw.write("Hola Manuel");
		osw.close(); //indispensable para que funcione correctamente
		
		// Esperar a que el proceso termine
        int exitCode = p.waitFor(); 
        
        // Obtener el valor de salida (exit code)
        if (exitCode == 0) {
            System.out.println("El proceso terminó correctamente con código de salida: " + exitCode);
        } else {
            System.out.println("El proceso terminó con errores. Código de salida: " + exitCode);
        }

        // Mostrar la salida del proceso
        Auxiliar.salida_comando(p);  
		
	}
	

	

}
