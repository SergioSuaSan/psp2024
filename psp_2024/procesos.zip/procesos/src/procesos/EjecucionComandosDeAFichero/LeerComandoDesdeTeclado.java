package procesos.EjecucionComandosDeAFichero;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class LeerComandoDesdeTeclado { //LeerComandoDesdeTeclado

	public static void main(String[] args) {
		/*
		 * crea un programa que lea un comando del teclado, lo ejecute como proceso y guarde su salida en un archivo llamado "salida.txt". 
		 * la salida de error, sin embargo, se visualizará en la consola de Eclipse.
		 */
		 Scanner teclado = new Scanner(System.in); //Creo un scanner para que se introduzca el comando al teclado 
	        
	        // Leer el comando del teclado
	        System.out.print("Introduce el comando a ejecutar: ");
	        String comando = teclado.nextLine();

	        try {
	            // Crear el proceso usando ProcessBuilder
	            ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/C", comando);
	            //indicamos cmd.exe porque  indicamos explícitamente que quieres ejecutar un comando en la consola de comandos
	            /*indicamos /C para que ejecute el comando que sigue y luego termine. 
	             * Es decir, ejecuta el comando y cierra la ventana de la consola después de completarlo
	             */
	            Process process = pb.start(); // Iniciar el proceso
	            
	            // Configurar para capturar la salida del comando
	            InputStream inputStream = process.getInputStream(); // getInputStream permite obtener la salida del proceso hijo y se lee linea por linea
	            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
	            //el InputStreamReader lo usamos convertir los bytes del InputStream a caracteres
	            //el BufferedReader para hacer una lectura eficiente  
	            
	            // Crear un BufferedWriter para guardar/escribir la salida en un archivo que vamos a llamar "salida.txt"
	            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("salida.txt")));
	            //1º creamos un FileOutputStream para escribir bytes especificando que se escribiran en el archivo salida.txt
	            //2º creamos un OutPutStreamWriter ya que queremos convertir esos bytes a caracteres
	            //3º Creamos el BufferedWriter para escribir en bloque 

	            String line;
	            // Leer la salida del comando y escribir en el archivo
	            while ((line = reader.readLine()) != null) { //mientras podamos seguir obteniendo linea de BufferedReader llamado reader
	                writer.write(line); //usamos el BufferedWriter llamado writer y escribimos una linea 
	                writer.newLine(); // Añadir nueva línea en el archivo
	            }
	            
	            // Cerrar el BufferedWriter
	            writer.close();

	            // Capturar la salida de error
	            InputStream errorStream = process.getErrorStream(); 
	            /*
	             * getErrorStream se utiliza para obtener un flujo de entrada que proporciona la salida de error del proceso que se está ejecutando
	             * 
	             */
	            BufferedReader errorReader = new BufferedReader(new InputStreamReader(errorStream));
	            //pasamos los bytes del InputStream a caracteres con InputStreamReader para leer y a BufferedReader para leer de forma más eficiente
	            String errorLine;
	            // Leer y mostrar los errores en la consola
	            while ((errorLine = errorReader.readLine()) != null) {
	            	/*
	            	 * errorReader.readLine(): intenta leer una línea de texto del BufferedReader llamado errorReader
	            	 * el resultado de errorReader.readLine() se asigna a la variable errorLine
	            	 * esto significa que errorLine contendrá el contenido de la línea que se acaba de leer o null si no hay más líneas
	            	 */
	                System.err.println(errorLine); // System.err es un flujo de salida en Java que se utiliza específicamente para imprimir mensajes de error
	            }

	            // Esperar a que el proceso termine
	            int exitValue = process.waitFor();
	            System.out.println("El proceso terminó con el código de salida: " + exitValue);

	        } catch (IOException | InterruptedException e) {
	            e.printStackTrace(); // Manejo de excepciones
	        } finally {
	            teclado.close(); // Cerrar el escáner
	        }
	}

}
