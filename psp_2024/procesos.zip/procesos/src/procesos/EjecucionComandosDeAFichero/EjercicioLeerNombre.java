package procesos.EjecucionComandosDeAFichero;

import java.io.InputStream;
import java.io.OutputStream;

public class EjercicioLeerNombre {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String clase = "procesos.EjecucionComandosDeAFichero.LeerNombre"; 
		
		ProcessBuilder pb = new ProcessBuilder("java", "-cp", ".\\bin", 
				clase, "funciona"); 
		
		try {
			Process p = pb.start(); //creamos el proceso 
			Auxiliar.salida_comando(p);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
}
