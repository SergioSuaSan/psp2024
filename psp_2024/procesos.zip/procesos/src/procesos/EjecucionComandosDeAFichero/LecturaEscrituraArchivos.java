package procesos.EjecucionComandosDeAFichero;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class LecturaEscrituraArchivos {

	public static void main(String[] args) throws IOException {
		 // Creación de un FileInputStream para leer el archivo comandos.bat
        // Se recuperan los bytes del archivo para ser procesados
		FileInputStream fis = new FileInputStream(".\\src\\procesos\\EjecucionComandosDeAFichero\\comandos.bat"); 
		/*
		 raiz del proyecto . carpeta actual, ver directorio show in system explorer */
		//& nos permite ejecutar varios comandos a la vez 
		 // El archivo 'comandos.bat' se encuentra en la carpeta procesos dentro del proyecto
		InputStreamReader isr = new InputStreamReader(fis, "UTF-8"); // // Se convierte el flujo de bytes a caracteres con InputStreamReader (usando UTF-8)
		BufferedReader br = new BufferedReader(isr); //creacción de un BufferedReader sobre el InputStreamReader para leer los caracteres del archivo de manera eficiente
		
	
		// Creación de un FileOutputStream para escribir las salidas del comando en 'salida.txt'
		FileOutputStream archivo_w = new FileOutputStream("salida.txt"); //creamos FileOutputScream para escribir/guardar streams de bytes
		OutputStreamWriter fw = new OutputStreamWriter(archivo_w); //  // Se convierte el flujo de bytes a caracteres para escribir en el archivo de salida
		BufferedWriter bw = new BufferedWriter(fw); //creacion del BufferedWriter para escribir/guardar los resultados de salida
		
		// // Creación de un archivo para escribir los errores del comando en 'error.txt'
		FileOutputStream archivo_we = new FileOutputStream("error.txt");
		OutputStreamWriter fwe = new OutputStreamWriter(archivo_we);
		BufferedWriter bwe = new BufferedWriter(fwe); //// BufferedWriter para escribir los errores
		
		
		 // Variable para almacenar cada línea de comandos del archivo 
		String linea_com = null;
		 // Variable para almacenar cada línea de comandos del archivo
		List<String> comando = new ArrayList<String>();

		//Variable para controlar el valor de salida de la terminación del proceso
		int exitVal;
		
		// Mientras haya líneas en el archivo 'comandos.bat', se leerán y procesarán 
		while((linea_com=br.readLine()) != null)
		{
			comando.add("CMD"); // Añadimos el comando CMD para ejecutar en el terminal
			comando.add("/C"); // /C indica que el CMD ejecutará el comando y luego se cerrará
			// en conclusión para que el processbluider ejecute correctamente luego
			
			//Descomposición de la línea de tokens y reconstrucción del comando como lista de Strings usando el espacio (" ") como delimitador
			 
			StringTokenizer st = new StringTokenizer(linea_com," ");
			while (st.hasMoreTokens() ) {
			       String s1 = st.nextToken(); // Extraemos el siguiente token del comando
			       comando.add(s1); // Lo añadimos a la lista del comando
			        //System.out.println(s1);
			      }
			
			// Creación de un proceso con ProcessBuilder usando la lista de comando 
			ProcessBuilder pb = new ProcessBuilder(comando);
			Process p; //// Variable para almacenar el proceso
			
			try {
				p = pb.start(); // Iniciamos la ejecución del comando como un proceso
				
				//Para ver por consola las salidas en vez de llevarlas a archivos
				//PracticaCmd.salida_comando(p);
				//PracticaCmd.salida_comando_error(p);
				
				//Lectura de las salidas de los comandos-procesos hijos 
				//y escritura de los archivos de salida y de error
				//SALIDA NORMAL

			InputStream	is = p.getInputStream(); // Lectura de la salida del proceso (output del comando)
				InputStreamReader isr2 = new InputStreamReader(is);
				BufferedReader br2 = new BufferedReader(isr2);

				String resultado = null;
				// Leemos cada línea de la salida del proceso y la escribimos en el archivo de salida
				while((resultado = br2.readLine())!= null) {					
						//System.out.println(resultado); //
						bw.write(resultado + "\n"); // Escribimos el resultado en 'salida.txt'
				}
				
				
				// Lectura de los errores del proceso (si los hubiera)
				InputStream isE = p.getErrorStream();
				InputStreamReader isr2E = new InputStreamReader(isE);
				BufferedReader br2E = new BufferedReader(isr2E);

				String resultadoE = null;
				while((resultadoE = br2E.readLine())!= null) {	//Lectura de los errores del proceso (si los hubiera)				
						//System.out.println(resultado); //
						bwe.write(resultadoE + "\n"); // Escribimos los errores en 'error.txt'
                }
				}
				
				/*
				// Sirve para esperar la finalización del proceso
                // y registrar el valor de salida del proceso (0 si el proceso fue exitoso)
				exitVal = p.waitFor();
				bwe.write(linea_com + " --> " + "Valor de Salida: " 
				+ String.valueOf(exitVal) + "\n\n");
				//System.out.println("Valor de Salida: " + exitVal);
				*/
				
			catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Comando incorrecto"); //// En caso de que haya un error al ejecutar el proceso, mostramos un mensaje de error
			}
			/*
			catch (InterruptedException e) { //
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
			*/
			
			//System.out.println(comando);
			
			//
			comando.clear(); // Limpiamos la lista de comandos para poder leer y ejecutar el siguiente comando

		}
		
		// // Cerramos los BufferedWriter y BufferedReader al terminar
		bw.close();
		bwe.close();
		br.close();
		
	}

}
