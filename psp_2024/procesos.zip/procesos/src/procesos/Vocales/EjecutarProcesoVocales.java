package procesos.Vocales;

import java.io.File;
import java.io.IOException;

public class EjecutarProcesoVocales {

	public static void main(String[] args) {
		 // Creamos una instancia de CrearProcesoVocales pasándole la vocal y el archivo como Strings MIO
		//CrearProcesoVocales cpv = new CrearProcesoVocales("a", "archivoVocales.txt"); 
		
		//instanciacion del objeto fichero a utilizar SUYO 
		//. --> se refire a procesos luego entramos a src y luego al paquete procesos y luego al paquete vocales y finalmente ahí ponemos el archivo 
		File archivoVocales2 = new File (".\\src\\procesos\\Vocales\\fichero_vocales2.txt"); 
		//creamos instancia de crearProcesovocales pasandole el char y el file (COMO LO HA HECHO ÉL)
		CrearProcesoVocales cpvSUYO = new CrearProcesoVocales('e', archivoVocales2); 
		
		
		
		
		/*try { MÍO 
			cpv.getP().waitFor(); //esperamos a que el proceso finalice 
			Vocales vocales = new Vocales(); //creamos un objeto vocales para contar luego las vocales del archivo 
			
			//instanciacion del objeto fichero a utilizar 
			File archivoVocales = new File("C:\\Users\\Usuario\\OneDrive\\Escritorio\\2º DAM\\WorkSpace PSP\\procesos\\archivoVocales.txt");

			if (!archivoVocales.exists()) { //si el archivo no existe 
			    try {
			        boolean creado = archivoVocales.createNewFile();
			        if (creado) {
			            System.out.println("Archivo creado exitosamente.");
			        } else {
			            System.out.println("El archivo ya existía.");
			        }
			    } catch (IOException e) {
			        e.printStackTrace();
			    }
			} else {
			    System.out.println("El archivo ya existe.");
			}
			int numeroVocales = vocales.contarVocales('a', archivoVocales); 
		} catch (Exception e) {
			// TODO: handle exception
		} */
		
	}

}
