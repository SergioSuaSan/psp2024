package procesos.Vocales;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Vocales {

//	private String fichero;
//	private char vocal;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (args.length == 2) {
			String voc = args[0]; //el primer argumento es un string 
			char vocal = voc.charAt(0); //ese string le pasamos a vocal
			File fichero = new File(args[1]); //el segundo argumento es un fichero  PERO ES LA RUTA DEL FICHERO COMO STRING 
			int numVocales = contarVocales(vocal, fichero); //utilizamos el metodo contar vocales pasandole la vocal y el fichero y lo almacenamos en numVocales
			System.out.println("vocal " + vocal + " -> " + numVocales); //imprimimos la vocal y el numero de veces que se repite 
			
		} else {
			// no se hace nada
		}
	}
	
	public static int contarVocales(char vocal, File fichero) { //ese fichero tiene que tener ruta absoluta 
		int numVocales = 0;
		try {
			
			FileReader fr = new FileReader(fichero);
			int letra = 0;

			while ((letra = fr.read()) != -1) { //mientras que se pueda ir leyendo caracter pro caracter 
				if ((char) letra == vocal) { //si esa letra es la vocal 
					numVocales++; //aumentamos el numero de ocurrencias 
				}
			}
			
			fr.close();
			return numVocales;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return numVocales;
	}

}
