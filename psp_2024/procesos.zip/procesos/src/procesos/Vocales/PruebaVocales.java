package procesos.Vocales;

import java.io.File;

public class PruebaVocales {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File fichero = new File(".\\src\\procesos\\Vocales\\fichero_vocales2.txt"); 
		CrearProcesoVocales cpv = new CrearProcesoVocales('a', fichero); 
	}

}
