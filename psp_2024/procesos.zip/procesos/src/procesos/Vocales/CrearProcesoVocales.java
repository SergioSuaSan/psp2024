package procesos.Vocales;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class CrearProcesoVocales {
/*
 * Esta clase se encarga de crear el proceso con la clase Vocales pasandole como argumentos 
 * el String con la letra y el archivo
 * 
 */
	
	public String vocalABuscar;
	public String archivo; 
	public Process p;
	
	public Process getP() {
		return p;
	}
	
	/*public CrearProcesoVocales(String vocalABuscar, String archivo) { //MÍO
		this.vocalABuscar = vocalABuscar; 
		this.archivo = archivo; 
		
		
		//OPCION SI SE PASARA UN FILE
		//String clase = "procesos.Vocales.Vocales"; //aquí la clase Vocales 
        // Construir el comando para ejecutar el proceso, incluyendo la vocal y el archivo 
		//ProcessBuilder pb = new ProcessBuilder("java", clase, vocalABuscar, archivo.getAbsolutePath()); 
		
	     try {
	            ProcessBuilder pb = new ProcessBuilder("java", "Vocales", vocalABuscar, archivo);
	            pb.redirectOutput(new File(archivo));  // Guardar resultado en un archivo
	            //redirige la salida el proceso a un archivo donde se guarda 
	            this.p = pb.start();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	} */
	
	public CrearProcesoVocales(char vocal, File fichero) { //SUYO

		//asignaciones de los argumentos a las variables de clase para el carácter
		//y el fichero
		this.vocalABuscar = String.valueOf(vocal); 
		this.archivo = fichero.getAbsolutePath(); 
		
		//Variables String para la clase, el carácter y el fichero que se utilizan
		//en el constructor de ProcessBuilder
		String clase = "procesos.Vocales.Vocales"; /// La clase que ejecutará el proceso (suponiendo que es "Vocales") SE REFIERE AL PAQUETE EN EL QUE ESTAMOS Y LA CLASE 
		String letra = String.valueOf(vocal);
		String archivo = fichero.getAbsolutePath(); //ABSOLUTE PATH ABSOLUTA
													//VALUE OF RELATIVA 
		
		//Construcción del proceso (se usa el método directory pero se puede usar la
		//classpath.
		//y letra y archivo porque me lo pide al main 
		ProcessBuilder pb = new ProcessBuilder("java", "-cp", ".\\bin", clase, letra, archivo); //DECIRLE LA RUTA 
		
		//establece el directorio donde esta la clase 
		// HACER UN CD
		
		//ProcessBuilder pb = new ProcessBuilder("java","procesos.Vocales.Vocales",letra,archivo); 
		//pb.directory( new File(".\\bin")

		
		try {
			// Lanzamiento del proceso
	        Process proceso = pb.start();

	        // Recolección del resultado del (sub)proceso
	        BufferedReader reader = new BufferedReader(new InputStreamReader(proceso.getInputStream()));
	        String linea;
	        while ((linea = reader.readLine()) != null) {
	            System.out.println(linea);
	        }

	        // Espera a que el proceso termine y obtiene el código de salida
	        int exitCode = proceso.waitFor();
	        System.out.println("Proceso terminado con código de salida: " + exitCode);
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

	}
	
	

	
	
	
}
