package procesos.Pablito;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class EscriboEnArchivo {
	/*
	 * Crear una clase EscriboEnArchivo que escriba "Pablito clavó un clavito" en el archivo que se elija. 
	 * Crear otra clase LeoDeArchivo que sea capaz de leer lo que hay en ese archivo y mostrarlo por consola. 
	 * Crear otra clase EjecutoLasOtras que lance como procesos a las otras dos y consiga el mismo resultado que si fuesen ejecutadas por su cuenta.
	 */
	
	//esta clase debe escribir en el archivo que se elija para ello le voy a pedir que lo introduzca por consola
	public void pedirComando() throws IOException {
		Scanner teclado = new Scanner(System.in); 
		System.out.println("Introduce la ruta del archivo: ");
		String rutaArchivo = teclado.nextLine(); 
		File archivo = new File("rutaArchivo"); 
		FileWriter fw = new FileWriter(archivo); 
		BufferedWriter bw = new BufferedWriter(fw); 
		bw.write("Pablito clavó un clavito");
		bw.close();
	}
	
	
}
