package procesos.esriboyleo;

import java.io.FileWriter;
import java.io.IOException;

public class EscriboEnArchivo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//poenmos la ruta del paquete y luego el nombre que le queremos dar al archivo como txt
		FileWriter fw = new FileWriter("C:\\Users\\Usuario\\OneDrive\\Escritorio\\2º DAM\\WorkSpace PSP\\procesos\\src\\procesos\\esriboyleo\\archivoEsriboyLeo.txt"); 
		fw.write("Que sea lo que Dios quiera");
		fw.close();
	}

}
