package procesos.esriboyleo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LeoDeArchivo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileReader fr = new FileReader("C:\\Users\\Usuario\\OneDrive\\Escritorio\\2º DAM\\WorkSpace PSP\\procesos\\src\\procesos\\esriboyleo\\archivoEsriboyLeo.txt");
		BufferedReader br = new BufferedReader(fr);
		String linea = ""; 
		
		while ((linea=br.readLine()) !=null) {
			System.out.println(linea);
		}
	}

}
