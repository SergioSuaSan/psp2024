package procesos.esriboyleo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ProcessBuilder.Redirect;

public class EjecutoEscriboYLeo {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		//"java" y se pone -cp, ruta carpeta bin --> . carpeta que te encuentras y bin paquetes y nombre de la clase a ejecutar 
		ProcessBuilder pb1 = new ProcessBuilder("java", "-cp", ".\\bin", "procesos.escriboyleo.EscriboEnArchivo" ); 
		Process proceso1 = pb1.start(); 
		proceso1.waitFor();
		ProcessBuilder pb2 = new ProcessBuilder("java", "-cp", ".\\bin", "procesos.escriboyleo.LeoDeArchivo" ).redirectOutput(Redirect.INHERIT); 
		//con redirectOutput le dices al proceso cual será su salida, que será la misma que la del proceso actual por el INHERIT 
		Process proceso2 = pb2.start();
		proceso2.waitFor(); 
		
		//pero no se ve nada entonces necesito recoger el subproceso, ya que el proceso padre/superior es la ejecuccion del programa java  
		 /*InputStream is = proceso2.getInputStream(); //porque es el proceso 2 quien escribe realmente por el syso  
		 InputStreamReader isr = new InputStreamReader(is); 
		 BufferedReader bf = new BufferedReader(isr);  //esto me permite leer 
		 String linea; 
		 while ((linea = bf.readLine()) != null ) { 
			System.out.println(linea);
		}*/
	
	}

}
