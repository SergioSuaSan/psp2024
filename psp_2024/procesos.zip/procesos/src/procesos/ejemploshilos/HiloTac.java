package procesos.ejemploshilos;

public class HiloTac extends Thread {
	
	public void run() {
		while (true) {
			System.out.println("TAC");
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  //los argumentos son milisegundos, esto es 1 segundo 
		}
	}

}
