package procesos.ejemploshilos;

public class Hilo1R implements Runnable { 
	
	public static void main(String[] args) {
		//al thread le debes pasar un objeto que implemente runnable
		
		Hilo1R hilo1r = new Hilo1R();  //creamos una clase que tiene la interfaz runnable
		Thread hilo1t = new Thread(hilo1r); //para poder pasarle a thread un objeto que implementa runnable AHORA ESTO SÍ ES EL HILO BUENO 
		hilo1t.start(); //hilo1.start(); //esto llama al metodo run()
		
	}

	@Override
	public void run() {
		System.out.println("Se ha ejecutado el hilo runnable");
		
	}

}
