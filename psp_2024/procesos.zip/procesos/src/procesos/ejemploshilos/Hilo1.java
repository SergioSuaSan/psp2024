package procesos.ejemploshilos;

public class Hilo1 extends Thread{

	public void run() { //codigo que se va a ejecutar cuando se ejecute el hilo
		System.out.println("Se ha ejecutado el hilo ");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hilo1 hilo1 = new Hilo1(); 
		hilo1.start(); //esto llama al metodo run()
	}

}
