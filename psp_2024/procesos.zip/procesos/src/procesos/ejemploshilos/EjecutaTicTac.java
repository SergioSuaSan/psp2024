package procesos.ejemploshilos;

public class EjecutaTicTac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//creamos unos hilos llamando al constructores de hilotic e hilotac 
		Thread h1 = new HiloTic();
		Thread h2 = new HiloTac();
		//hacemos que se ejecute run con el start 
		h1.start();
		h2.start();
	}

}
